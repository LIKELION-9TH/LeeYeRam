from django.contrib import admin
from .models import Scrap
# Register your models here.
admin.site.register(Scrap)